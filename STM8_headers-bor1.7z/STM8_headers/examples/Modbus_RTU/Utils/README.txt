Simple Modbus RTU masters for testing purposes
==============================================

Arduino_master:
  - tested with Arduino Mega 2560
  - uses library "Modbus-Master-Slave-for-Arduino" 
  - requires additional TTL<->RS-485 adapter 

PC_master:
  - tested with Python 2.x 
  - uses library "modbus_tk" 
  - requires additional USB<->RS-485 dongle 
