PC_master:
  - tested with Python 3.x 
  - uses library "modbus_tk" 
  - requires additional USB<->RS-485 dongle 
  - scans for valid IDs. In case of conflicts, request new IDs
