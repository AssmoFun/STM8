CRC calculation from [https://github.com/basilhussain/stm8-crc](https://github.com/basilhussain/stm8-crc)

Notes:
  - these routines are compatible with all toolchains 

