CRC calculation from [https://github.com/basilhussain/stm8-crc](https://github.com/basilhussain/stm8-crc)

Notes:
  - for optimum size & speed use ASM routines ([SDCC](http://sdcc.sourceforge.net/) only due to inline ASM)
  - for other toolchains use C routines
