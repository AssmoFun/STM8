A rather small Modbus server/slave implementation for STM8 mikrocontrollers. With
this library very simple devices can be realized in less than 1500 bytes of flash.
Although already in use in a couple of places, please consider this to be work in
progress.

Note: this is a port for STM8 of https://github.com/mbs38/yaMBSiavr for AVR
